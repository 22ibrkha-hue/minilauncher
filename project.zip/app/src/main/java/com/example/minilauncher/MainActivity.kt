package com.example.minilauncher

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import org.json.JSONObject
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {

    // ---- Edit these ----
    private val LAT = 51.5074                       // your latitude (London default)
    private val LON = -0.1278                       // your longitude
    private val ORDER = listOf("netflix", "prime", "disney", "youtube", "plex") // dock order, matched against app names
    private val HIDDEN = setOf<String>()            // package names to hide from the dock
    // --------------------

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var dock: LinearLayout
    private lateinit var label: TextView
    private lateinit var weather: LinearLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun glass(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }

    private fun text(size: Float, bold: Boolean = false) = TextView(this).apply {
        textSize = size
        setTextColor(Color.WHITE)
        setShadowLayer(8f, 0f, 2f, 0x66000000)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this)

        // Wallpaper: put wallpaper.jpg in res/drawable (falls back to a plain blue)
        val wp = resources.getIdentifier("wallpaper", "drawable", packageName)
        root.addView(ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            if (wp != 0) setImageResource(wp) else setImageDrawable(GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xFF6F8FC4.toInt(), 0xFF2C4170.toInt(), 0xFF111C38.toInt())))
        }, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        // Clock + date, top left
        val clock = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        clock.addView(TextClock(this).apply {
            format12Hour = "HH:mm"; format24Hour = "HH:mm"
            textSize = 72f; setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            setShadowLayer(8f, 0f, 2f, 0x66000000)
        })
        clock.addView(TextClock(this).apply {
            format12Hour = "EEEE, d MMMM"; format24Hour = "EEEE, d MMMM"
            textSize = 20f; setTextColor(Color.WHITE)
            setShadowLayer(8f, 0f, 2f, 0x66000000)
        })
        root.addView(clock, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.TOP or Gravity.START)
            .apply { setMargins(dp(56), dp(32), 0, 0) })

        // Weather glass panel, top right
        weather = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = glass(0x33FFFFFF, 20)
            setPadding(dp(24), dp(16), dp(24), dp(16))
            visibility = View.GONE
        }
        root.addView(weather, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.TOP or Gravity.END)
            .apply { setMargins(0, dp(40), dp(56), 0) })

        // App dock, bottom centre
        dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = glass(0x44000000, 28)
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        root.addView(dock, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
            .apply { bottomMargin = dp(72) })

        label = text(16f).apply { gravity = Gravity.CENTER }
        root.addView(label, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
            .apply { bottomMargin = dp(36) })

        setContentView(root)
        refreshWeather()
    }

    override fun onResume() {
        super.onResume()
        loadApps()
    }

    private fun rank(name: String): Int {
        val n = name.lowercase()
        val i = ORDER.indexOfFirst { n.contains(it) }
        return if (i >= 0) i else ORDER.size
    }

    private fun loadApps() {
        val pm = packageManager
        var apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER), 0)
        if (apps.isEmpty()) apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)

        val list = apps
            .filter { it.activityInfo.packageName != packageName && it.activityInfo.packageName !in HIDDEN }
            .sortedWith(compareBy({ rank(it.loadLabel(pm).toString()) }, { it.loadLabel(pm).toString().lowercase() }))

        dock.removeAllViews()
        list.forEachIndexed { index, info ->
            val pkg = info.activityInfo.packageName
            val name = info.loadLabel(pm).toString()
            val tile = FrameLayout(this).apply {
                background = glass(0x22FFFFFF, 16)
                setPadding(dp(8), dp(8), dp(8), dp(8))
                isFocusable = true
                isClickable = true
                setOnClickListener {
                    (pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg))
                        ?.let { startActivity(it) }
                }
                setOnFocusChangeListener { v, focused ->
                    v.animate().scaleX(if (focused) 1.2f else 1f).scaleY(if (focused) 1.2f else 1f)
                        .setDuration(120).start()
                    v.background = glass(if (focused) 0x88FFFFFF.toInt() else 0x22FFFFFF, 16)
                    if (focused) label.text = name
                }
                addView(ImageView(context).apply { setImageDrawable(info.loadIcon(pm)) },
                    FrameLayout.LayoutParams(dp(56), dp(56)))
            }
            dock.addView(tile, LinearLayout.LayoutParams(dp(72), dp(72)).apply {
                setMargins(dp(6), 0, dp(6), 0)
            })
            if (index == 0) tile.requestFocus()
        }
    }

    private fun refreshWeather() {
        thread {
            try {
                val url = "https://api.open-meteo.com/v1/forecast?latitude=$LAT&longitude=$LON" +
                    "&current=temperature_2m&hourly=temperature_2m&forecast_hours=6&timezone=auto"
                val j = JSONObject(URL(url).readText())
                val now = Math.round(j.getJSONObject("current").getDouble("temperature_2m")).toInt()
                val h = j.getJSONObject("hourly")
                val times = h.getJSONArray("time")
                val temps = h.getJSONArray("temperature_2m")
                val hours = (0 until times.length()).map {
                    times.getString(it).takeLast(5).take(2) to Math.round(temps.getDouble(it)).toInt()
                }
                ui.post { showWeather(now, hours) }
            } catch (_: Exception) { /* keep the panel hidden if offline */ }
        }
        ui.postDelayed({ refreshWeather() }, 30 * 60 * 1000L)
    }

    private fun showWeather(now: Int, hours: List<Pair<String, Int>>) {
        weather.removeAllViews()
        weather.addView(text(44f).apply { this.text = "$now°" })
        hours.forEach { (hour, temp) ->
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
            }
            col.addView(text(14f).apply { this.text = hour })
            col.addView(text(18f, true).apply { this.text = "$temp°" })
            weather.addView(col, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply {
                setMargins(dp(20), 0, 0, 0)
            })
        }
        weather.visibility = View.VISIBLE
    }

    @Deprecated("Launcher: Back does nothing")
    override fun onBackPressed() { /* stay on the home screen */ }
}
